# Image-Manipulation
Image Manipulation: Use CSS to create a basic image gallery with thumbnail images that enlarge when clicked. Implement a simple image slideshow that automatically transitions between images using HTML and CSS.
