# Simple-Webpage
Create a simple webpage with a heading, paragraph, and image using HTML and CSS. Build a basic form with a single input field and a submit button using HTML and CSS. Design and code a simple navigation menu with three links using HTML and CSS.
